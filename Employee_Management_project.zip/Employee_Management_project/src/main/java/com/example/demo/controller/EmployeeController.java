package com.example.demo.controller;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService empservice;
    
   

    @PostMapping("/addEmp")
    public Employee saveEmployee(@RequestBody Employee employee) {
        return empservice.addEmployee(employee);
    }

    @GetMapping("/allEmp")
    public List<Employee> getAllEmployees() {
        return empservice.getAllEmployees();
    }

    @GetMapping("/findEmp/{id}")
    public Optional<Employee> getEmployeeById(@PathVariable int id) {
        return empservice.findEmpById(id);
    }

    @DeleteMapping("removeEmp/{id}")
    public String deleteEmployee(@PathVariable int id) {
        return empservice.removeEmployee(id);
    }

    @PutMapping("/update/{id}")
    public String updateEmployee(@PathVariable int id, @RequestBody Employee employee) {
        return empservice.updateEmployee(id, employee);
    }
}
