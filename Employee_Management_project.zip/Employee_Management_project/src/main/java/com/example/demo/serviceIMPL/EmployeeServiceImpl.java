package com.example.demo.serviceIMPL;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepo;
import com.example.demo.service.EmployeeService;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepo repo;

    @Override
    public Employee addEmployee(Employee employee) {
        return repo.save(employee);
    }

    @Override
    public String removeEmployee(int id) {
        repo.deleteById(id);
        return "Employee removed with id: " + id;
    }

    @Override
    public Optional<Employee> findEmpById(int id) {
        return repo.findById(id);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return repo.findAll();
    }

    @Override
    public String updateEmployee(int id, Employee employee) {
        Optional<Employee> existingEmployee = repo.findById(id);
        if (existingEmployee.isPresent()) {
            Employee empToUpdate = existingEmployee.get();
            empToUpdate.setName(employee.getName());
            empToUpdate.setAge(employee.getAge());
            empToUpdate.setState(employee.getState());
            empToUpdate.setType(employee.getType());
            empToUpdate.setSalary(employee.getSalary());
            repo.save(empToUpdate);
            return "Employee updated with id: " + id;
        } else {
            throw new RuntimeException("Employee not found");
        }
    }
}
