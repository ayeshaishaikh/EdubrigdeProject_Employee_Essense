package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import com.example.demo.model.Employee;

public interface EmployeeService {
    Employee addEmployee(Employee employee);
    String removeEmployee(int id);
    Optional<Employee> findEmpById(int id);
    List<Employee> getAllEmployees();
    String updateEmployee(int id, Employee employee);
}
