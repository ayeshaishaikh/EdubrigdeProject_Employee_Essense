document.addEventListener('DOMContentLoaded', function() {
    const addEmployeeForm = document.getElementById('addEmployeeForm');
    const deleteEmployeeForm = document.getElementById('deleteEmployeeForm');

    // Handle Add Employee Form Submission
    addEmployeeForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        const formData = new FormData(addEmployeeForm);
        const employeeData = {
            name: formData.get('name'),
            age: formData.get('age'),
            state: formData.get('state'),
            type: formData.get('type'),
            salary: formData.get('salary')
        };

        fetch('/employees/addEmp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(employeeData)
        })
        .then(response => response.json())
        .then(data => {
            alert('Employee added successfully!');
            addEmployeeForm.reset();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to add employee.');
        });
    });

    // Handle Delete Employee Form Submission
    deleteEmployeeForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        const employeeId = document.getElementById('deleteId').value;

        fetch(`/employees/deleteEmp/${employeeId}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.ok) {
                alert('Employee deleted successfully!');
                deleteEmployeeForm.reset();
            } else {
                throw new Error('Failed to delete employee.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to delete employee.');
        });
    });
});
